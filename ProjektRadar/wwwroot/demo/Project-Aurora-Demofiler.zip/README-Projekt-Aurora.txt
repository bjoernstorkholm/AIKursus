PROJEKT AURORA – DEMOFILER

Disse filer er fiktive og udviklet til ProjektRadar. De indeholder bevidst håndterbare uoverensstemmelser om tidsplan, budget, sikkerhedstest, dataejerskab, leverandørstatus, risici og styregruppebeslutninger.

Anbefalet demo:
1. Upload alle 8 projektdokumenter til ProjektRadar.
2. Analysen starter automatisk.
3. Gennemgå risikoniveau, radar, konflikter, evidens og handlingsplan.
4. Redigér ansvar, deadline, prioritet og status.
5. Brug kun knappen 'Download resultat som PDF' hvis et PDF-resultat ønskes.
